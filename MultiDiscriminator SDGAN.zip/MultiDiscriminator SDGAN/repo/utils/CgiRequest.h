#ifndef CGI_REQUEST_H
#define CGI_REQUEST_H

/**
 Provides access to the CGI variables in the environment.
 */
class CgiRequest
{
public:
    CgiRequest();
    ~CgiRequest();

    const char* get(const char* key);

private:
    struct Item {
        char* key;
        char* value;
    }* _items;

    unsigned _numItems;

    char fromHex( const char* str );
    void unescape( char* dest, const char* src );
};

#endif // CGI_REQUEST_H

