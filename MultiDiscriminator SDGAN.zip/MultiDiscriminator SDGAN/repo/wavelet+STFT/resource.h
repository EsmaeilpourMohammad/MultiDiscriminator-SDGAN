//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wavelet.rc
//
#define IDB_SEL                              101
#define IDB_PLAY_OUT                         102
#define IDB_PLAY_OVER                        103
#define IDB_PLAY_DOWN                        104
#define IDB_STOP_OUT                         105
#define IDB_STOP_OVER                        106
#define IDB_STOP_DOWN                        107
#define IDB_SEL_OUT                          108
#define IDB_SEL_OVER                         109
#define IDB_SEL_DOWN                         110
#define IDB_PLAYTOOL_OUT                     111
#define IDB_PLAYTOOL_OVER                    112
#define IDB_PLAYTOOL_DOWN                    113
#define IDI_ICON                             114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
