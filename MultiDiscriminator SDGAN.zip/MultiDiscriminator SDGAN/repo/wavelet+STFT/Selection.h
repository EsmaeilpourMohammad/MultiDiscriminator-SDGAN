// -----------------------------------------------------------------------------
// Copyright 2008 Steve Hanov. All rights reserved.
//
// For permission to use, please contact steve.hanov@gmail.com. Permission will
// usually be granted without charge.
// -----------------------------------------------------------------------------
#ifndef SELECTION_H
#define SELECTION_H

#include <windows.h>
#include <vector>

/**
  * Represents the user's selection.
  */
class Selection
{
public:
    Selection();
    virtual ~Selection();

    typedef std::vector<RECT> RectList;

    // coordinates in rows/samples
    RectList rects;
};

#endif // SELECTION_

