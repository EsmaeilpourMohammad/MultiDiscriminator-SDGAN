// -----------------------------------------------------------------------------
// Copyright 2008 Steve Hanov. All rights reserved.
//
// For permission to use, please contact steve.hanov@gmail.com. Permission will
// usually be granted without charge.
// -----------------------------------------------------------------------------
#include "WaveletOptions.h"

WaveletOptions* _options = NULL;

WaveletOptions::WaveletOptions()
{
    release = false;
    autoEnhance = true;
    _dispatcher->registerEvent( this, IDC_AUTO_ENHANCE_TOGGLE_REQ );
}

WaveletOptions::~WaveletOptions()
{

}

void
WaveletOptions::onEvent( unsigned event )
{
    switch( event ) {
        case IDC_AUTO_ENHANCE_TOGGLE_REQ:
            autoEnhance = !autoEnhance;
            _dispatcher->dispatch( IDC_AUTO_ENHANCE_TOGGLE_CNF );
            break;
    }

}
