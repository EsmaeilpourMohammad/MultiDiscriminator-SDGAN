#credit to Simon C. 
from scipy import linalg
# for Schur or QZ decomposition
from math import log
def update_loss(entr1, entr2):
	sum_score = 0.0
	for i in range(len(actual)):
		D,N =linalg.qz(entr1, entr2)
			lambda1 = linalg.norm(N)
			fnorm1=lambda1-linalg.norm(entr1)
			lambda2 = linalg.norm(entr2)*D
			fnorm2=lambda2-linalg.norm(entr2)
		sum_score += actual[i] * log(1e-15 + predicted[i]+(fnorm2-fnorm1))
	mean_sum_score = 1.0 / len(actual) * sum_score
	return -mean_sum_score